using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using EPiServer.Core.PropertySettings;

namespace Netcat.Core.CustomProperties.TextBox
{
    public class PropertyStringWithLimitedCharacterSettingUI : PropertySettingsControlBase
    {
        static List<TextBoxMode> _textMode = new List<System.Web.UI.WebControls.TextBoxMode>();
        static PropertyStringWithLimitedCharacterSettingUI()
        {
            _textMode.Add(TextBoxMode.SingleLine);
            _textMode.Add(TextBoxMode.MultiLine);
            _textMode.Add(TextBoxMode.Password);
        }

        private DropDownList _ddlTextMode;
        private System.Web.UI.WebControls.TextBox _txtLimitChar;
        const string TxtLimitCharId = "txtLimitChar";

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            _ddlTextMode = new DropDownList();
            _ddlTextMode.ID = "dllTextMode";
            _ddlTextMode.Items.Add(new ListItem("SingleLine", ((int)TextBoxMode.SingleLine).ToString()));
            _ddlTextMode.Items.Add(new ListItem("MultiLine", ((int)TextBoxMode.MultiLine).ToString()));
            _ddlTextMode.Items.Add(new ListItem("Password", ((int)TextBoxMode.Password).ToString()));

            _txtLimitChar = new System.Web.UI.WebControls.TextBox();
            _txtLimitChar.ID = TxtLimitCharId;
            _txtLimitChar.Text = "500";

            var unique = Guid.NewGuid().ToString().Replace("-", "");
            var functionIsNumberName = "IsNumeric" + unique;
            var functionLostFocusName = "OnLostFocus" + unique;

            Controls.Add(new Literal() { Text = "Limited number of character (must be integer):<br>" });
            _txtLimitChar.Attributes["onblur"] = functionLostFocusName + "(this);";
            Controls.Add(_txtLimitChar);
             
            Controls.Add(new RegularExpressionValidator() { ControlToValidate = TxtLimitCharId, ValidationExpression = "[0-9]+", Text = "Limit Character must be integer", ErrorMessage = "Limit Char must be integer" });

            Controls.Add(new Literal() { Text = "<br>" });
            Controls.Add(new Literal() { Text = "TextBoxMode:<br>" });
            Controls.Add(_ddlTextMode);

            var scriptCheckIsNumber = string.Format("<script type='text/javascript'>{0}</script>",
                "function " + functionIsNumberName + "(input) {return (input - 0) == input && input.length > 0;}"
                + "function " + functionLostFocusName + "(txt) {if (" + functionIsNumberName + "(txt.value)) {return;}"
                + " else {alert('Your input is not an integer'); }}");

            Controls.Add(new Literal() { Text = scriptCheckIsNumber });

        }

        public override void LoadSettingsUI(IPropertySettings settings)
        {
            EnsureChildControls();
            var dbVal = (PropertyStringWithLimitedCharacterSetting)settings;
            _txtLimitChar.Text = dbVal.LimitChar.ToString();
            _ddlTextMode.SelectedValue = dbVal.TextBoxMode.ToString();
        }

        public override void UpdateSettings(IPropertySettings settings)
        {
            EnsureChildControls();
            var dbVal = (PropertyStringWithLimitedCharacterSetting)settings;
            int limChar = 500;
            if (int.TryParse(_txtLimitChar.Text.Trim(new[] { '.', ',' }), out limChar))
            {
                dbVal.LimitChar = limChar;
                dbVal.TextBoxMode = Convert.ToInt32(_ddlTextMode.SelectedValue);
            }

        }
    }
}