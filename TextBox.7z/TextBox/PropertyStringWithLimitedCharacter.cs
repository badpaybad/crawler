using System;
using System.Collections.Generic;
using System.Text;
using EPiServer;
using EPiServer.Core;
using EPiServer.Core.PropertySettings;
using EPiServer.DataAbstraction;
using EPiServer.PlugIn;
using EPiServer.Web.PropertyControls;

namespace Netcat.Core.CustomProperties.TextBox
{
    /// <summary>
    /// Custom PropertyData implementation
    /// </summary>
    [Serializable]
    [PageDefinitionTypePlugIn]
    [PropertySettings(typeof(PropertyStringWithLimitedCharacterSetting),true)]
    public class PropertyStringWithLimitedCharacter : EPiServer.Core.PropertyLongString
    {
        // TODO: Override members of EPiServer.Core.PropertyLongString to provide your own logic.


        public override EPiServer.Core.IPropertyControl CreatePropertyControl()
        {
            return new PropertyStringWithLimitedCharacterControl();
        }

    }
}
