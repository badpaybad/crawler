using System;
using System.Web.UI.WebControls;

namespace Netcat.Core.CustomProperties.TextBox
{
    /// <summary>
    /// PropertyControl implementation used for rendering PropertyStringWithLimitedCharacter data.
    /// </summary>
    public class PropertyStringWithLimitedCharacterControl : EPiServer.Web.PropertyControls.PropertyStringControl
    {
        /*
        Override CreateXXXControls to control the appearance of the property data in different rendering conditions.

        public override void CreateDefaultControls()        - Used when rendering the view mode.
        public override void CreateEditControls()           - Used when rendering the property in edit mode.
        public override void CreateOnPageEditControls()     - used when rendering the property for "On Page Edit".

        */

        private System.Web.UI.WebControls.TextBox _txt;
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            _txt = new System.Web.UI.WebControls.TextBox();
        }

        /// <summary>
        /// Gets the PropertyStringWithLimitedCharacter instance for this IPropertyControl.
        /// </summary>
        /// <value>The property that is to be displayed or edited.</value>
        public PropertyStringWithLimitedCharacter PropertyStringWithLimitedCharacter
        {
            get
            {
                return PropertyData as PropertyStringWithLimitedCharacter;
            }
        }
        public override void CreateOnPageEditControls()
        {
            BuildTextBox();
        }
        public override void CreateEditControls()
        {
            BuildTextBox();
        }

        private void BuildTextBox()
        {
            var settings =
                PropertyData.GetSetting(typeof(PropertyStringWithLimitedCharacterSetting)) as
                PropertyStringWithLimitedCharacterSetting;
            string toolTip = string.Format("{0} Limited character(s)", settings.LimitChar);
            _txt.ToolTip = toolTip;
            _txt.MaxLength = settings.LimitChar;
            _txt.TextMode = (TextBoxMode)settings.TextBoxMode;
            var lblCounterId = "lblCounter-" + Guid.NewGuid().ToString().Replace("-", "");
            _txt.Attributes["onkeyup"] = "return !isLimitedChar(this);";
            Controls.Clear();
            Controls.Add(_txt);
            Controls.Add(new Literal() { Text = string.Format("<span id='{0}'>0</span> char(s)", lblCounterId) });
            string scriptCountChar = string.Format("<script type='text/javascript'>{0}</script>",
                "function CountLimitedChar(sender){document.getElementById('" + lblCounterId + "').innerHTML=sender.value.length;}" +
                " function isLimitedChar(sender) { if (sender.value.length < " + settings.LimitChar + ") {CountLimitedChar(sender);return false;}"
                + "else {sender.value = sender.value.substr(0, " + (settings.LimitChar ) + ");CountLimitedChar(sender); return true;} }");
            Controls.Add(new Literal() { Text = scriptCountChar });
        }

        public override void ApplyEditChanges()
        {
            SetValue(_txt.Text);
            base.ApplyEditChanges();
        }

        public override void ApplyOnPageEditChanges()
        {
            SetValue(_txt.Text);
            base.ApplyOnPageEditChanges();
        }

        public override void ApplyChanges()
        {
            SetValue(_txt.Text);
            base.ApplyChanges();
        }
    }
}
