using EPiServer.Core.PropertySettings;

namespace Netcat.Core.CustomProperties.TextBox
{
    [PropertySettingsUI(AdminControl = typeof(PropertyStringWithLimitedCharacterSettingUI))]
    public class PropertyStringWithLimitedCharacterSetting : PropertySettingsBase
    {
        public int LimitChar { get; set; }
        public int TextBoxMode { get; set; }

        public override IPropertySettings GetDefaultValues()
        {
            return new PropertyStringWithLimitedCharacterSetting() { LimitChar = 500, TextBoxMode = (int)System.Web.UI.WebControls.TextBoxMode.SingleLine };
        }
    }
}