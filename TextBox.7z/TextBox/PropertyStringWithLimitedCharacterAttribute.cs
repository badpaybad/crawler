using System;
using System.Web.UI.WebControls;
using PageTypeBuilder;

namespace Netcat.Core.CustomProperties.TextBox
{
    public class PropertyStringWithLimitedCharacterAttribute : Attribute, IUpdatePropertySettings<PropertyStringWithLimitedCharacterSetting>
    {
        public virtual int LimitChar { get; set; }
        public virtual TextBoxMode TextMode { get; set; }
        public virtual bool OverWriteExistSetting { get; set; }

        public void UpdateSettings(PropertyStringWithLimitedCharacterSetting settings)
        {
            settings.LimitChar = LimitChar;
            settings.TextBoxMode = (int) TextMode;
        }

        public int GetSettingsHashCode(PropertyStringWithLimitedCharacterSetting settings)
        {
            return settings.GetHashCode();
        }

        public bool OverWriteExistingSettings
        {
            get
            {
                return OverWriteExistSetting;
            }
        }
    }
}